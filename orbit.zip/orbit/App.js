import * as Font from 'expo-font';
import { StyleSheet, View, Text, TextInput, TouchableOpacity, FlatList, KeyboardAvoidingView, ActivityIndicator, Animated, ScrollView } from 'react-native';
import { useState, useEffect, useRef } from 'react';
import { useFonts, Playfair_Display_500Medium } from '@expo-google-fonts/playfair-display';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SUPABASE_URL = 'https://ubicjjsnmdulacxsrdhb.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InViaWNqanNubWR1bGFjeHNyZGhiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg2MTcxOTksImV4cCI6MjA5NDE5MzE5OX0.7ar3OgtwYfDb6OY9J0dEeos0ujbAJJlVxdWAduWSjaU';

const C = {
  bg: '#F4F7FA',
  white: '#FFFFFF',
  midnight: '#1C2B48',
  cerulean: '#8EB1D1',
  baby: '#A7C7E7',
  platinum: '#E8ECEF',
  bluegrey: '#C4D8E5',
  text: '#1C2B48',
  textMuted: '#8EB1D1',
  bubble: '#A7C7E7',
  aiBubble: '#FFFFFF',
};

function OrbitSpinner({ confirmed }) {
  const spin = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!confirmed) {
      Animated.loop(Animated.timing(spin, { toValue: 1, duration: 900, useNativeDriver: true })).start();
    } else spin.stopAnimation();
  }, [confirmed]);
  const rotate = spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  return (
    <View style={{ width: 16, height: 16, alignItems: 'center', justifyContent: 'center', alignSelf: 'flex-end', marginTop: 4 }}>
      <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: C.midnight, position: 'absolute', opacity: 0.6 }} />
      <Animated.View style={{ width: 12, height: 12, borderRadius: 6, borderWidth: 1.5, position: 'absolute', borderColor: confirmed ? C.midnight : 'rgba(28,43,72,0.2)', borderTopColor: C.midnight, opacity: confirmed ? 0.6 : 1, transform: [{ rotate }] }} />
    </View>
  );
}

function MessageBubble({ item }) {
  return (
    <View style={[s.bubble, item.isAI ? s.aiBubble : s.meBubble]}>
      <Text style={[s.bubbleText, item.isAI ? s.aiText : s.meText]}>{item.text}</Text>
      {!item.isAI && <OrbitSpinner confirmed={item.confirmed} />}
    </View>
  );
}

const ONBOARDING = [
  {
    id: 'welcome',
    type: 'info',
    title: 'welcome to orbit',
    subtitle: 'your second brain.\nthoughts in, clarity out.',
    cta: 'get started',
  },
  {
    id: 'privacy',
    type: 'info',
    title: 'your thoughts are yours',
    subtitle: 'orbit never sells or shares your personal data. everything you write stays private and encrypted.',
    cta: 'i understand',
  },
  {
    id: 'name',
    type: 'input',
    title: "first, what's your name?",
    placeholder: 'your name…',
    key: 'name',
    cta: 'continue',
  },
  {
    id: 'use',
    type: 'choice',
    title: 'what do you want to use orbit for?',
    key: 'use',
    options: ['clear my head', 'track tasks & goals', 'remember everything', 'all of the above'],
    cta: 'continue',
  },
  {
    id: 'style',
    type: 'choice',
    title: 'how do you usually think?',
    key: 'style',
    options: ['bullet points', 'long rambles', 'voice notes', 'random chaos'],
    cta: 'continue',
  },
  {
    id: 'account',
    type: 'account',
    title: 'create your account',
    subtitle: 'save your data across devices',
    cta: 'create account',
  },
  {
    id: 'plan',
    type: 'plan',
    title: 'choose your plan',
    cta: 'start free',
  },
];

export default function App() {
  const [screen, setScreen] = useState('loading');
  const [onboardStep, setOnboardStep] = useState(0);
  const [profile, setProfile] = useState({ name: '', use: '', style: '' });
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [tab, setTab] = useState('chat');
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [events, setEvents] = useState([]);
  const [ideas, setIdeas] = useState([]);
  const [reminders, setReminders] = useState([]);
  const [orgLoading, setOrgLoading] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState('free');
  const flatListRef = useRef(null);
  const [fontsLoaded] = useFonts({ Playfair_Display_500Medium });

  useEffect(() => {
    async function init() {
      const done = await AsyncStorage.getItem('onboarding_done');
      const savedName = await AsyncStorage.getItem('user_name');
      if (done === 'true') {
        const name = savedName || 'you';
        setMessages([{ id: '1', text: 'hey ' + name + ', what\'s on your mind?', isAI: true, confirmed: true }]);
        setScreen('app');
      } else {
        setScreen('onboarding');
      }
    }
    init();
  }, []);

  async function finishOnboarding() {
    await AsyncStorage.setItem('onboarding_done', 'true');
    await AsyncStorage.setItem('user_name', profile.name || 'you');
    setMessages([{ id: '1', text: 'hey ' + (profile.name || 'you') + ', what\'s on your mind?', isAI: true, confirmed: true }]);
    setScreen('app');
  }

  async function loadOrganised() {
    setOrgLoading(true);
    try {
      const headers = { 'apikey': SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + SUPABASE_ANON_KEY };
      const [t, e, i, r] = await Promise.all([
        fetch(SUPABASE_URL + '/rest/v1/tasks?user_id=eq.test-user&order=created_at.desc', { headers }).then(r => r.json()),
        fetch(SUPABASE_URL + '/rest/v1/events?user_id=eq.test-user&order=created_at.desc', { headers }).then(r => r.json()),
        fetch(SUPABASE_URL + '/rest/v1/ideas?user_id=eq.test-user&order=created_at.desc', { headers }).then(r => r.json()),
        fetch(SUPABASE_URL + '/rest/v1/reminders?user_id=eq.test-user&order=created_at.desc', { headers }).then(r => r.json()),
      ]);
      setTasks(Array.isArray(t) ? t : []);
      setEvents(Array.isArray(e) ? e : []);
      setIdeas(Array.isArray(i) ? i : []);
      setReminders(Array.isArray(r) ? r : []);
    } catch (err) {} finally { setOrgLoading(false); }
  }

  useEffect(() => {
    if (tab === 'organised') loadOrganised();
  }, [tab]);

  async function toggleTask(id, done) {
    await fetch(SUPABASE_URL + '/rest/v1/tasks?id=eq.' + id, {
      method: 'PATCH',
      headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + SUPABASE_ANON_KEY, 'Content-Type': 'application/json', 'Prefer': 'return=minimal' },
      body: JSON.stringify({ done: !done })
    });
    setTasks(prev => prev.map(t => t.id === id ? { ...t, done: !t.done } : t));
  }

  async function sendMessage() {
    if (!input.trim()) return;
    const text = input;
    const userMessage = { id: Date.now().toString(), text, isAI: false, confirmed: false };
    setInput('');
    setMessages(prev => [...prev, userMessage]);
    setLoading(true);
    try {
      const response = await fetch(SUPABASE_URL + '/functions/v1/extract-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + SUPABASE_ANON_KEY, 'apikey': SUPABASE_ANON_KEY },
        body: JSON.stringify({ content: text, user_id: 'test-user' }),
      });
      const data = await response.json();
      setMessages(prev => prev.map(m => m.id === userMessage.id ? { ...m, confirmed: true } : m));
      const total = (data.tasks?.length || 0) + (data.events?.length || 0) + (data.ideas?.length || 0) + (data.reminders?.length || 0);
      if (total > 0) {
        setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), text: '◉ orbit captured ' + total + ' item' + (total > 1 ? 's' : ''), isAI: true, confirmed: true }]);
      }
    } catch (err) {
      setMessages(prev => prev.map(m => m.id === userMessage.id ? { ...m, confirmed: true } : m));
    } finally { setLoading(false); }
  }

  const filtered = search ? messages.filter(m => m.text?.toLowerCase().includes(search.toLowerCase())) : messages;

  const step = ONBOARDING[onboardStep];

  if (screen === 'loading') {
    return <View style={[s.container, { alignItems: 'center', justifyContent: 'center' }]}><Text style={{ fontSize: 32, color: C.midnight }}>◉</Text></View>;
  }

  if (screen === 'onboarding') {
    return (
      <View style={s.container}>
        <View style={s.onboardWrap}>
          <View style={s.progressRow}>
            {ONBOARDING.map((_, i) => (
              <View key={i} style={[s.progressDot, i <= onboardStep && s.progressDotActive]} />
            ))}
          </View>

          <View style={{ flex: 1, justifyContent: 'center', paddingHorizontal: 8 }}>
            <Text style={s.orbitLogo}>◉ orbit</Text>
            <Text style={s.onboardTitle}>{step.title}</Text>
            {step.subtitle && <Text style={s.onboardSubtitle}>{step.subtitle}</Text>}

            {step.type === 'input' && (
              <TextInput
                style={s.onboardInput}
                placeholder={step.placeholder}
                placeholderTextColor={C.textMuted}
                value={profile[step.key] || ''}
                onChangeText={v => setProfile(p => ({ ...p, [step.key]: v }))}
                autoFocus
              />
            )}

            {step.type === 'choice' && (
              <View style={s.choiceGrid}>
                {step.options.map(opt => (
                  <TouchableOpacity
                    key={opt}
                    style={[s.choiceBtn, profile[step.key] === opt && s.choiceBtnActive]}
                    onPress={() => setProfile(p => ({ ...p, [step.key]: opt }))}
                  >
                    <Text style={[s.choiceBtnText, profile[step.key] === opt && s.choiceBtnTextActive]}>{opt}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}

            {step.type === 'account' && (
              <View style={{ gap: 12, marginTop: 8 }}>
                <TextInput style={s.onboardInput} placeholder="email" placeholderTextColor={C.textMuted} value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
                <TextInput style={s.onboardInput} placeholder="password" placeholderTextColor={C.textMuted} value={password} onChangeText={setPassword} secureTextEntry />
              </View>
            )}

            {step.type === 'plan' && (
              <View style={{ gap: 12, marginTop: 8 }}>
                <TouchableOpacity style={[s.planCard, selectedPlan === 'free' && s.planCardActive]} onPress={() => setSelectedPlan('free')}>
                  <Text style={s.planTitle}>free</Text>
                  <Text style={s.planDesc}>brain dump, basic organisation, 30 messages/day</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[s.planCard, selectedPlan === 'pro' && s.planCardActive]} onPress={() => setSelectedPlan('pro')}>
                  <View style={s.planBadge}><Text style={s.planBadgeText}>7-day free trial</Text></View>
                  <Text style={s.planTitle}>orbit pro</Text>
                  <Text style={s.planDesc}>unlimited messages · AI memory retrieval · pattern insights · reminders · orbit becomes your memory</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>

          <TouchableOpacity
            style={[s.ctaBtn, { opacity: (step.type === 'choice' && !profile[step.key]) ? 0.4 : 1 }]}
            onPress={() => {
              if (onboardStep < ONBOARDING.length - 1) setOnboardStep(onboardStep + 1);
              else finishOnboarding();
            }}
          >
            <Text style={s.ctaBtnText}>{step.cta}</Text>
          </TouchableOpacity>

          {step.type !== 'account' && onboardStep > 0 && (
            <TouchableOpacity onPress={() => setOnboardStep(onboardStep - 1)} style={{ alignItems: 'center', paddingBottom: 8 }}>
              <Text style={{ color: C.textMuted, fontSize: 13 }}>back</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  }

  const orgSections = [
    { type: 'section', title: 'tasks', id: 's1' },
    ...tasks.map(t => ({ ...t, type: 'task' })),
    ...(tasks.length === 0 ? [{ type: 'empty', text: 'no tasks yet', id: 'e1' }] : []),
    { type: 'section', title: 'events', id: 's2' },
    ...events.map(e => ({ ...e, type: 'event' })),
    ...(events.length === 0 ? [{ type: 'empty', text: 'no events yet', id: 'e2' }] : []),
    { type: 'section', title: 'ideas', id: 's3' },
    ...ideas.map(i => ({ ...i, type: 'idea' })),
    ...(ideas.length === 0 ? [{ type: 'empty', text: 'no ideas yet', id: 'e3' }] : []),
    { type: 'section', title: 'reminders', id: 's4' },
    ...reminders.map(r => ({ ...r, type: 'reminder' })),
    ...(reminders.length === 0 ? [{ type: 'empty', text: 'no reminders yet', id: 'e4' }] : []),
  ];

  return (
    <View style={s.container}>
      {tab === 'chat' && (
        <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding" keyboardVerticalOffset={30}>
          <View style={s.header}>
            <Text style={s.headerText}>◉ orbit</Text>
            <TouchableOpacity onPress={() => { setShowSearch(!showSearch); setSearch(''); }}>
              <Text style={{ color: C.cerulean, fontSize: 22 }}>⌕</Text>
            </TouchableOpacity>
          </View>
          {showSearch && (
            <TextInput style={s.searchBox} value={search} onChangeText={setSearch} placeholder="search your thoughts…" placeholderTextColor={C.textMuted} autoFocus returnKeyType="done" onSubmitEditing={() => setShowSearch(false)} />
          )}
          <FlatList
            ref={flatListRef}
            data={filtered}
            keyExtractor={(item, index) => item?.id ?? index.toString()}
            contentContainerStyle={s.messageList}
            onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
            renderItem={({ item }) => <MessageBubble item={item} />}
          />
          {loading && <ActivityIndicator color={C.cerulean} style={{ marginBottom: 8 }} />}
          <View style={s.inputBar}>
            <TextInput
              style={s.input}
              value={input}
              onChangeText={setInput}
              placeholder="what's on your mind…"
              placeholderTextColor={C.textMuted}
              returnKeyType="send"
              onSubmitEditing={sendMessage}
              blurOnSubmit={true}
            />
            <TouchableOpacity style={s.sendBtn} onPress={sendMessage} disabled={loading}>
              <Text style={s.sendText}>↑</Text>
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      )}

      {tab === 'organised' && (
        <View style={{ flex: 1 }}>
          <View style={s.header}>
            <Text style={s.headerText}>organised</Text>
            <TouchableOpacity onPress={loadOrganised}>
              <Text style={{ color: C.cerulean, fontSize: 13 }}>refresh</Text>
            </TouchableOpacity>
          </View>
          {orgLoading ? <ActivityIndicator color={C.cerulean} style={{ marginTop: 40 }} /> : (
            <FlatList
              data={orgSections}
              keyExtractor={(item, index) => item?.id ?? index.toString()}
              contentContainerStyle={{ padding: 16, gap: 8 }}
              renderItem={({ item }) => {
                if (item.type === 'section') return <Text style={s.sectionLabel}>{item.title}</Text>;
                if (item.type === 'empty') return <Text style={s.emptyText}>{item.text}</Text>;
                if (item.type === 'task') return (
                  <TouchableOpacity style={s.card} onPress={() => toggleTask(item.id, item.done)}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                      <View style={{ width: 20, height: 20, borderRadius: 10, borderWidth: 1.5, borderColor: item.done ? C.midnight : C.bluegrey, backgroundColor: item.done ? C.midnight : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
                        {item.done && <Text style={{ color: '#fff', fontSize: 11 }}>✓</Text>}
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={[s.cardTitle, item.done && { color: C.textMuted, textDecorationLine: 'line-through' }]}>{item.title}</Text>
                        {item.due_date && <Text style={s.cardMeta}>due {item.due_date}</Text>}
                      </View>
                    </View>
                  </TouchableOpacity>
                );
                if (item.type === 'event') return (
                  <View style={s.card}>
                    <Text style={[s.cardMeta, { marginBottom: 4 }]}>event</Text>
                    <Text style={s.cardTitle}>{item.title}</Text>
                    {item.event_date_raw && <Text style={s.cardMeta}>{item.event_date_raw}</Text>}
                  </View>
                );
                if (item.type === 'idea') return (
                  <View style={[s.card, { borderLeftWidth: 2, borderLeftColor: C.baby }]}>
                    <Text style={[s.cardMeta, { marginBottom: 4 }]}>idea</Text>
                    <Text style={s.cardTitle}>{item.title}</Text>
                  </View>
                );
                if (item.type === 'reminder') return (
                  <View style={[s.card, { borderLeftWidth: 2, borderLeftColor: C.cerulean }]}>
                    <Text style={[s.cardMeta, { marginBottom: 4 }]}>reminder</Text>
                    <Text style={s.cardTitle}>{item.title}</Text>
                    {item.remind_at_raw && <Text style={s.cardMeta}>{item.remind_at_raw}</Text>}
                  </View>
                );
              }}
            />
          )}
        </View>
      )}

      <View style={s.tabBar}>
        <TouchableOpacity style={s.tab} onPress={() => setTab('chat')}>
          <Text style={[s.tabIcon, tab === 'chat' && s.tabActive]}>◉</Text>
          <Text style={[s.tabLabel, tab === 'chat' && s.tabActive]}>chat</Text>
        </TouchableOpacity>
        <TouchableOpacity style={s.tab} onPress={() => setTab('organised')}>
          <Text style={[s.tabIcon, tab === 'organised' && s.tabActive]}>☰</Text>
          <Text style={[s.tabLabel, tab === 'organised' && s.tabActive]}>organised</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { paddingTop: 60, paddingBottom: 16, paddingHorizontal: 20, borderBottomWidth: 0.5, borderBottomColor: C.platinum, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: C.white },
  headerText: { color: C.midnight, fontSize: 20, fontWeight: '500' },
  onboardTitle: { fontSize: 28, color: C.midnight, fontFamily: 'Playfair_Display_500Medium', lineHeight: 36, marginBottom: 12 },
headerText: { color: C.midnight, fontSize: 20, fontFamily: 'Playfair_Display_500Medium' },
planTitle: { fontSize: 18, color: C.midnight, fontFamily: 'Playfair_Display_500Medium', marginBottom: 6 },
  searchBox: { backgroundColor: C.white, color: C.midnight, margin: 12, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 10, fontSize: 15, borderWidth: 0.5, borderColor: C.bluegrey },
  messageList: { padding: 16, gap: 8 },
  bubble: { maxWidth: '80%', padding: 12, borderRadius: 18 },
  meBubble: { alignSelf: 'flex-end', backgroundColor: C.midnight, borderBottomRightRadius: 4 },
  aiBubble: { alignSelf: 'flex-start', backgroundColor: C.white, borderBottomLeftRadius: 4, borderWidth: 0.5, borderColor: C.platinum },
  bubbleText: { fontSize: 15, lineHeight: 21 },
  meText: { color: '#fff' },
  aiText: { color: C.midnight },
  inputBar: { flexDirection: 'row', padding: 12, paddingBottom: 40, gap: 7, borderTopWidth: 0.5, borderTopColor: C.platinum, alignItems: 'flex-end', backgroundColor: C.white },
  input: { flex: 1, backgroundColor: C.bg, color: C.midnight, borderRadius: 20, paddingHorizontal: 16, paddingVertical: 10, fontSize: 15, maxHeight: 100, borderWidth: 0.5, borderColor: C.bluegrey },
  sendBtn: { width: 38, height: 38, backgroundColor: C.midnight, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  sendText: { color: '#fff', fontSize: 18, fontWeight: '600' },
  tabBar: { flexDirection: 'row', borderTopWidth: 0.5, borderTopColor: C.platinum, backgroundColor: C.white, paddingBottom: 28 },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 10, gap: 2 },
  tabIcon: { color: C.bluegrey, fontSize: 18 },
  tabLabel: { color: C.bluegrey, fontSize: 11 },
  tabActive: { color: C.midnight },
  card: { backgroundColor: C.white, borderRadius: 12, padding: 14, borderWidth: 0.5, borderColor: C.platinum },
  cardTitle: { color: C.midnight, fontSize: 15 },
  cardMeta: { color: C.textMuted, fontSize: 12, marginTop: 4 },
  sectionLabel: { color: C.textMuted, fontSize: 11, fontWeight: '600', letterSpacing: 1, textTransform: 'uppercase', marginTop: 8 },
  emptyText: { color: C.bluegrey, fontSize: 13, paddingLeft: 4 },
  onboardWrap: { flex: 1, padding: 28, paddingTop: 60 },
  progressRow: { flexDirection: 'row', gap: 6, marginBottom: 40 },
  progressDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: C.platinum },
  progressDotActive: { backgroundColor: C.midnight },
  orbitLogo: { fontSize: 16, color: C.cerulean, marginBottom: 24, fontWeight: '500' },
  onboardTitle: { fontSize: 28, color: C.midnight, fontWeight: '500', lineHeight: 36, marginBottom: 12 },
  onboardSubtitle: { fontSize: 16, color: C.textMuted, lineHeight: 24, marginBottom: 32 },
  onboardInput: { backgroundColor: C.white, borderWidth: 0.5, borderColor: C.bluegrey, borderRadius: 14, paddingHorizontal: 18, paddingVertical: 14, fontSize: 16, color: C.midnight, marginTop: 8 },
  choiceGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 8 },
  choiceBtn: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20, borderWidth: 0.5, borderColor: C.bluegrey, backgroundColor: C.white },
  choiceBtnActive: { backgroundColor: C.midnight, borderColor: C.midnight },
  choiceBtnText: { color: C.midnight, fontSize: 14 },
  choiceBtnTextActive: { color: '#fff' },
  ctaBtn: { backgroundColor: C.midnight, borderRadius: 16, paddingVertical: 16, alignItems: 'center', marginBottom: 12 },
  ctaBtnText: { color: '#fff', fontSize: 16, fontWeight: '500' },
  planCard: { backgroundColor: C.white, borderRadius: 16, padding: 18, borderWidth: 0.5, borderColor: C.platinum },
  planCardActive: { borderColor: C.midnight, borderWidth: 1.5 },
  planTitle: { fontSize: 18, color: C.midnight, fontWeight: '500', marginBottom: 6 },
  planDesc: { fontSize: 13, color: C.textMuted, lineHeight: 20 },
  planBadge: { backgroundColor: C.baby, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 3, alignSelf: 'flex-start', marginBottom: 8 },
  planBadgeText: { fontSize: 11, color: C.midnight, fontWeight: '500' },
});