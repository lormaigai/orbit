import { StyleSheet, View, Text, TextInput, TouchableOpacity, FlatList, KeyboardAvoidingView, ActivityIndicator, Animated, Modal, Image } from 'react-native';
import { useState, useEffect, useRef } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import * as ImagePicker from 'expo-image-picker';

const SUPABASE_URL = 'https://ubicjjsnmdulacxsrdhb.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InViaWNqanNubWR1bGFjeHNyZGhiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg2MTcxOTksImV4cCI6MjA5NDE5MzE5OX0.7ar3OgtwYfDb6OY9J0dEeos0ujbAJJlVxdWAduWSjaU';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
const FREE_DAILY_LIMIT = 30;
const SIZE = 390;

const C = {
  bg: '#F4F7FA',  
  white: '#FFFFFF',
  midnight: '#1C2B48',
  cerulean: '#8EB1D1',
  baby: '#A7C7E7',
  platinum: '#E8ECEF',
  bluegrey: '#C4D8E5',
  textMuted: '#8EB1D1',
};

// ─── Orbit spinner: spinning arc around a dot ───────────────────────────────
function OrbitSpinner({ confirmed }) {
  const progress = useRef(new Animated.Value(0)).current;
  const anim = useRef(null);

  useEffect(() => {
    if (!confirmed) {
      anim.current = Animated.loop(
        Animated.timing(progress, { toValue: 1, duration: 800, useNativeDriver: true })
      );
      anim.current.start();
    } else {
      if (anim.current) anim.current.stop();
      progress.setValue(1);
    }
  }, [confirmed]);
  

  const rotate = progress.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });

  return (
    <View style={{ width: 18, height: 18, alignItems: 'center', justifyContent: 'center', alignSelf: 'flex-end', marginTop: 6 }}>
      <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: confirmed ? '#ffffff' : C.cerulean, position: 'absolute' }} />
      <Animated.View style={{
        width: 14, height: 14, borderRadius: 7, borderWidth: 1.5, position: 'absolute',
        borderTopColor: confirmed ? '#ffffff' : C.cerulean,
        borderRightColor: confirmed ? '#ffffff' : 'transparent',
        borderBottomColor: confirmed ? '#ffffff' : 'transparent',
        borderLeftColor: confirmed ? '#ffffff' : 'transparent',
        transform: [{ rotate }]
      }} />
    </View>
  );
}


function MessageBubble({ item }) {
  if (item.isImage) {
    return (
      <View style={[s.bubble, s.meBubble, { padding: 4, backgroundColor: 'transparent' }]}>
        <Image
          source={{ uri: item.imageUrl }}
          style={{ width: 200, height: 200, borderRadius: 14 }}
          resizeMode="cover"
        />
      </View>
    );
  }
  return (
    <View style={[s.bubble, item.isAI ? s.aiBubble : s.meBubble]}>
      <Text style={[s.bubbleText, item.isAI ? s.aiText : s.meText]}>{item.text}</Text>
      {!item.isAI && <OrbitSpinner confirmed={item.confirmed} />}
    </View>
  );
}

// ─── Pro upgrade modal ───────────────────────────────────────────────────────
function ProModal({ visible, onClose, onActivate }) {
  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.45)' }}>
        <View style={{ backgroundColor: C.white, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 28, paddingBottom: 52 }}>
          <Text style={{ fontSize: 26, color: C.midnight, fontWeight: '600', marginBottom: 6 }}>◉ orbit pro</Text>
          <Text style={{ fontSize: 15, color: C.textMuted, marginBottom: 24, lineHeight: 22 }}>unlock your full second brain</Text>
          {[
            '∞   unlimited messages',
            '🔁  memory resurfacing',
            '💡  weekly insights tab',
            '📤  export notes as PDF',
            '🤖  AI reply mode (coming soon)',
          ].map(f => (
            <Text key={f} style={{ fontSize: 15, color: C.midnight, marginBottom: 12, lineHeight: 22 }}>{f}</Text>
          ))}
          <TouchableOpacity
            style={{ backgroundColor: C.midnight, borderRadius: 16, paddingVertical: 16, alignItems: 'center', marginTop: 20 }}
            onPress={onActivate}>
            <Text style={{ color: '#fff', fontSize: 16, fontWeight: '600' }}>start 7-day free trial</Text>
            <Text style={{ color: C.baby, fontSize: 12, marginTop: 4 }}>then $6.99/month — cancel anytime</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onClose} style={{ marginTop: 16, alignItems: 'center' }}>
            <Text style={{ color: C.textMuted, fontSize: 14 }}>maybe later</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

// ─── Onboarding steps ────────────────────────────────────────────────────────
const ONBOARDING = [
  { id: 'welcome', type: 'info', title: 'welcome to orbit', subtitle: 'your second brain.', cta: 'get started' },
  { id: 'privacy', type: 'info', title: 'your thoughts are yours', subtitle: 'orbit never sells or shares your personal data. everything you write stays private and encrypted.', cta: 'i understand' },
  { id: 'name', type: 'input', title: "first, what's your name?", placeholder: 'your name…', key: 'name', cta: 'continue' },
  { id: 'use', type: 'choice', title: 'what do you want to use orbit for?', key: 'use', options: ['clear my head', 'track tasks & goals', 'remember everything', 'to-do list', 'brainstorming', 'all of the above'], cta: 'continue' },
  { id: 'style', type: 'choice', title: 'how do you usually think?', key: 'style', options: ['bullet points', 'long rambles', 'voice notes', 'random chaos'], cta: 'continue' },
  { id: 'account', type: 'account', title: 'create your account', subtitle: 'save your data across devices', cta: 'create account' },
];

// ─── Tutorial steps ──────────────────────────────────────────────────────────
const TUTORIAL = [
  {
    id: 't1',
    emoji: '💬',
    title: 'just type what\'s on your mind',
    subtitle: 'orbit listens to everything — tasks, ideas, events, reminders. no formatting needed, just talk naturally.',
    examples: ['"remind me to call mum tomorrow"', '"idea: start a podcast about design"', '"meeting with jake on friday at 3pm"'],
  },
  {
    id: 't2',
    emoji: '☰',
    title: 'orbit organises it for you',
    subtitle: 'everything you type gets automatically sorted into tasks, events, ideas & reminders — find it all in the organised tab.',
    examples: ['"buy groceries" → task', '"dentist thursday 2pm" → event', '"what if i learned to code?" → idea'],
  },
  {
    id: 't3',
    emoji: '📸',
    title: 'save photos as memories',
    subtitle: 'tap ⊕ in chat to attach a photo. all your images live in the memories tab — like a visual journal.',
    examples: ['"screenshot of that recipe"', '"photo of the whiteboard"', '"pic from the trip"'],
  },
  {
    id: 't4',
    emoji: '◉',
    title: 'you\'re ready to orbit',
    subtitle: 'you get 30 free messages a day. just start typing — your second brain is ready.',
    examples: [],
  },
];

// ─── Main App ────────────────────────────────────────────────────────────────
export default function App() {
  const [isLogin, setIsLogin] = useState(false);
  const [tutorialStep, setTutorialStep] = useState(0);
  const [showProfile, setShowProfile] = useState(false);
  const [profileEmail, setProfileEmail] = useState('');
  const [dailyCount, setDailyCount] = useState(0);
  const [images, setImages] = useState([]); // for organised tab gallery
  const [imagesLoading, setImagesLoading] = useState(false);
  const [screen, setScreen] = useState('loading');
  const [onboardStep, setOnboardStep] = useState(0);
  const [profile, setProfile] = useState({ name: '', use: '', style: '' });
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [tab, setTab] = useState('chat');
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [events, setEvents] = useState([]);
  const [ideas, setIdeas] = useState([]);
  const [reminders, setReminders] = useState([]);
  const [orgLoading, setOrgLoading] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState('free');
  const [userId, setUserId] = useState('anonymous');
  const [userPlan, setUserPlan] = useState('free');
  const [showPaywall, setShowPaywall] = useState(false);
  const [limitReached, setLimitReached] = useState(false);
  const flatListRef = useRef(null);
  const MAX_STORED_MESSAGES = 100;

  // Persist chat history to AsyncStorage (local cache) whenever messages change
  useEffect(() => {
    if (messages.length === 0 || !userId || userId === 'anonymous') return;
    const toSave = messages.slice(-MAX_STORED_MESSAGES);
    AsyncStorage.setItem('chat_messages_' + userId, JSON.stringify(toSave)).catch(() => {});
  }, [messages, userId]);

  // ── Helpers ────────────────────────────────────────────────────────────────

  // Always use real session token so Supabase RLS works correctly
  async function getAuthHeaders() {
    try {
      const { data } = await supabase.auth.getSession();
      const token = data?.session?.access_token || SUPABASE_ANON_KEY;
      return { 'apikey': SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + token };
    } catch {
      return { 'apikey': SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + SUPABASE_ANON_KEY };
    }
  }

  async function getDailyCount() {
    try {
      const today = new Date().toISOString().split('T')[0];
      const stored = await AsyncStorage.getItem('daily_msg');
      if (!stored) return 0;
      const { date, count } = JSON.parse(stored);
      return date === today ? count : 0;
    } catch { return 0; }
  }

  async function incrementDailyCount() {
    const today = new Date().toISOString().split('T')[0];
    const count = await getDailyCount();
    const newCount = count + 1;
    await AsyncStorage.setItem('daily_msg', JSON.stringify({ date: today, count: newCount }));
    setDailyCount(newCount);
    return newCount;
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    // Clear session data but NOT per-user message cache (chat_messages_<uid>)
    const keysToRemove = ['onboarding_done', 'user_name', 'user_id', 'user_plan', 'trial_end', 'daily_msg', 'chat_messages'];
    await AsyncStorage.multiRemove(keysToRemove);
    setShowProfile(false);
    setMessages([]);
    setImages([]);
    setTasks([]); setEvents([]); setIdeas([]); setReminders([]);
    setScreen('onboarding');
    setOnboardStep(0);
    setProfile({ name: '', use: '', style: '' });
    setEmail(''); setPassword('');
    setUserId('anonymous');
    setUserPlan('free');
    setDailyCount(0);
    setProfileEmail('');
  }

  // Returns the current plan string ('free' or 'pro') so callers can use it immediately
  async function checkPlan() {
    try {
      const plan = await AsyncStorage.getItem('user_plan') || 'free';
      const trialEnd = await AsyncStorage.getItem('trial_end');
      // If pro trial has expired, revert to free
      if (plan === 'pro' && trialEnd && new Date() > new Date(trialEnd)) {
        await AsyncStorage.setItem('user_plan', 'free');
        setUserPlan('free');
        const count = await getDailyCount();
        if (count >= FREE_DAILY_LIMIT) setLimitReached(true);
        return 'free';
      }
      setUserPlan(plan);
      if (plan === 'free') {
        const count = await getDailyCount();
        if (count >= FREE_DAILY_LIMIT) setLimitReached(true);
      }
      return plan;
    } catch { return 'free'; }
  }

  async function activatePro() {
    const trialEnd = new Date();
    trialEnd.setDate(trialEnd.getDate() + 7);
    await AsyncStorage.setItem('user_plan', 'pro');
    await AsyncStorage.setItem('trial_end', trialEnd.toISOString());
    setUserPlan('pro');
    setLimitReached(false);
    setShowPaywall(false);
  }

  // Memory resurface — Pro only, uses real auth token
  async function checkMemories(uid, plan) {
    if (!uid || uid === 'anonymous' || plan !== 'pro') return;
    try {
      const headers = await getAuthHeaders();
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const res = await fetch(
        SUPABASE_URL + '/rest/v1/tasks?user_id=eq.' + uid +
        '&done=eq.false&created_at=lt.' + yesterday.toISOString() +
        '&order=created_at.desc&limit=3',
        { headers }
      );
      const oldTasks = await res.json();
      if (!Array.isArray(oldTasks) || oldTasks.length === 0) return;
      const others = oldTasks.length - 1;
      const memoryText =
        '🔁 still on your mind: "' + oldTasks[0].title + '"' +
        (others > 0 ? ' and ' + others + ' other task' + (others > 1 ? 's' : '') : '') +
        ' — done or still going?';
      setMessages(prev => {
        if (prev.some(m => m.isMemory)) return prev;
        return [{ id: 'memory-' + Date.now(), text: memoryText, isAI: true, confirmed: true, isMemory: true }, ...prev];
      });
    } catch (e) {}
  }

  // Save a single message to Supabase (fire-and-forget)
  async function saveMessageToSupabase(msg, uid) {
    if (!uid || uid === 'anonymous' || msg.isMemory) return;
    try {
      await supabase.from('chat_messages').insert({
        user_id: uid,
        msg_id: msg.id,
        text: msg.text || null,
        image_url: msg.imageUrl || null,
        is_ai: msg.isAI || false,
        is_image: msg.isImage || false,
        is_memory: msg.isMemory || false,
        confirmed: msg.confirmed !== false,
      });
    } catch (e) {}
  }

  // Load full chat history from Supabase for a user
  async function loadMessagesFromSupabase(uid) {
    if (!uid || uid === 'anonymous') return null;
    try {
      const { data, error } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('user_id', uid)
        .order('created_at', { ascending: true })
        .limit(MAX_STORED_MESSAGES);
      if (error || !data || data.length === 0) return null;
      return data.map(row => ({
        id: row.msg_id,
        text: row.text || '',
        imageUrl: row.image_url || undefined,
        isAI: row.is_ai,
        isImage: row.is_image,
        isMemory: row.is_memory,
        confirmed: row.confirmed,
      }));
    } catch (e) { return null; }
  }

  // ── Initialise ─────────────────────────────────────────────────────────────
  useEffect(() => {
    async function init() {
      try {
        const done = await AsyncStorage.getItem('onboarding_done');
        const savedName = await AsyncStorage.getItem('user_name');
        const savedId = await AsyncStorage.getItem('user_id');
        const uid = savedId || 'anonymous';
        if (savedId) setUserId(savedId);
        if (done === 'true') {
          const name = savedName || 'you';
          const plan = await checkPlan();
          // Load chat history — try Supabase first, fall back to local cache
          const remoteMessages = await loadMessagesFromSupabase(uid);
          if (remoteMessages && remoteMessages.length > 0) {
            setMessages(remoteMessages);
          } else {
            const localKey = 'chat_messages_' + uid;
            const savedMessages = await AsyncStorage.getItem(localKey)
              || await AsyncStorage.getItem('chat_messages'); // legacy key
            const parsed = savedMessages ? JSON.parse(savedMessages) : [];
            if (parsed.length > 0) {
              setMessages(parsed);
              // Migrate legacy local messages up to Supabase
              for (const msg of parsed) saveMessageToSupabase(msg, uid);
            } else {
              setMessages([{ id: '1', text: "hey " + name + ", what's on your mind?", isAI: true, confirmed: true }]);
            }
          }
          // Load profile info
          setProfile(p => ({ ...p, name: savedName || 'you' }));
          const { data: sessionData } = await supabase.auth.getSession();
          if (sessionData?.session?.user?.email) setProfileEmail(sessionData.session.user.email);
          const cnt = await getDailyCount();
          setDailyCount(cnt);
          setScreen('app');
          checkMemories(uid, plan);
        } else {
          setScreen('onboarding');
        }
      } catch (e) {
        setScreen('onboarding');
      }
    }
    init();

    // Listen for auth state changes — fires when user confirms their email
    // and Supabase redirects back to the app
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        const savedName = await AsyncStorage.getItem('user_name');
        const uid = session.user.id;
        setUserId(uid);
        setProfileEmail(session.user.email || '');
        setProfile(p => ({ ...p, name: savedName || 'you' }));
        await AsyncStorage.setItem('user_id', uid);
        await AsyncStorage.setItem('onboarding_done', 'true');
        const plan = await checkPlan();
        const cnt = await getDailyCount();
        setDailyCount(cnt);
        checkMemories(uid, plan);
        // If they just confirmed email, go to tutorial; otherwise go to app
        setScreen(prev => prev === 'verify-email' ? 'tutorial' : prev === 'app' ? 'app' : 'tutorial');
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  // ── Auth ───────────────────────────────────────────────────────────────────
  async function finishOnboarding() {
    if (!email || !password) { alert('please enter email and password'); return; }
    setLoading(true);
    try {
      let uid;
      if (isLogin) {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) { alert('login error: ' + error.message); setLoading(false); return; }
        uid = data.user?.id || 'anonymous';
      } else {
        const { data, error } = await supabase.auth.signUp({ email, password });
        if (error) { alert('signup error: ' + error.message); setLoading(false); return; }

        // Save name and email regardless — used on the verify screen
        await AsyncStorage.setItem('user_name', profile.name || 'you');
        setProfileEmail(email);

        if (!data.session) {
          // Supabase requires email confirmation — session is null until confirmed
          setScreen('verify-email');
          setLoading(false);
          return;
        }
        // Email confirmation is disabled in Supabase — session came back immediately
        uid = data.user?.id || 'anonymous';
      }
      setUserId(uid);
      await AsyncStorage.setItem('user_plan', 'free');
      setUserPlan('free');
      await AsyncStorage.setItem('onboarding_done', 'true');
      await AsyncStorage.setItem('user_name', profile.name || 'you');
      await AsyncStorage.setItem('user_id', uid);
      setProfileEmail(email);
      setMessages([{ id: '1', text: isLogin ? "welcome back!" : "hey " + (profile.name || 'you') + ", what's on your mind?", isAI: true, confirmed: true }]);
      if (isLogin) {
        setScreen('app');
      } else {
        setTutorialStep(0);
        setScreen('tutorial');
      }
    } catch (err) {
      alert('error: ' + err.message);
    } finally { setLoading(false); }
  }

  // ── Organised tab ──────────────────────────────────────────────────────────
  async function loadOrganised() {
    setOrgLoading(true);
    try {
      const headers = await getAuthHeaders();
      const uid = await AsyncStorage.getItem('user_id') || userId;
      const [t, e, i, r] = await Promise.all([
        fetch(SUPABASE_URL + '/rest/v1/tasks?user_id=eq.' + uid + '&order=created_at.desc', { headers }).then(r => r.json()),
        fetch(SUPABASE_URL + '/rest/v1/events?user_id=eq.' + uid + '&order=created_at.desc', { headers }).then(r => r.json()),
        fetch(SUPABASE_URL + '/rest/v1/ideas?user_id=eq.' + uid + '&order=created_at.desc', { headers }).then(r => r.json()),
        fetch(SUPABASE_URL + '/rest/v1/reminders?user_id=eq.' + uid + '&order=created_at.desc', { headers }).then(r => r.json()),
      ]);
      setTasks(Array.isArray(t) ? t : []);
      setEvents(Array.isArray(e) ? e : []);
      setIdeas(Array.isArray(i) ? i : []);
      setReminders(Array.isArray(r) ? r : []);
    } catch (err) {} finally { setOrgLoading(false); }
  }
  async function loadImages() {
  setImagesLoading(true);
  try {
    const uid = await AsyncStorage.getItem('user_id') || userId;
    const { data, error } = await supabase.storage
      .from('orbit-images')
      .list(uid, { limit: 50, sortBy: { column: 'created_at', order: 'desc' } });

    if (error) { alert('images error: ' + error.message); return; }

    const urls = (data || [])
      .filter(f => f.name && f.name !== '.emptyFolderPlaceholder')
      .map(f => {
        const { data: urlData } = supabase.storage
          .from('orbit-images')
          .getPublicUrl(uid + '/' + f.name);
        return urlData.publicUrl;
      });
    setImages(urls);
  } catch (e) {
    alert('catch error: ' + e.message);
  } finally {
    setImagesLoading(false);
  }
}

useEffect(() => {
  if (tab === 'organised') loadOrganised();
  if (tab === 'memories') loadImages();
}, [tab]);
async function pickAndUploadImage() {
  const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!perm.granted) { alert('please allow photo access'); return; }

  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
    quality: 0.7,
  });
  if (result.canceled) return;

  const uri = result.assets[0].uri;
  const uid = await AsyncStorage.getItem('user_id') || userId;
  const fileName = uid + '/' + Date.now() + '.jpg';

  const response = await fetch(uri);
  const blob = await response.blob();

  const uploadRes = await fetch(
    SUPABASE_URL + '/storage/v1/object/orbit-images/' + fileName,
    {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + SUPABASE_ANON_KEY,
        'apikey': SUPABASE_ANON_KEY,
        'Content-Type': 'image/jpeg',
      },
      body: blob,
    }
  );

  if (!uploadRes.ok) { alert('upload failed'); return; }

  const publicUrl = SUPABASE_URL + '/storage/v1/object/public/orbit-images/' + fileName;

  const imgMsg = {
    id: Date.now().toString(),
    text: '',
    imageUrl: publicUrl,
    isAI: false,
    confirmed: true,
    isImage: true,
  };
  setMessages(prev => [...prev, imgMsg]);
  saveMessageToSupabase(imgMsg, uid);
  loadImages();
}
  async function toggleTask(id, done) {
  async function pickAndUploadImage() {
  const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!perm.granted) { alert('please allow photo access'); return; }

  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
    quality: 0.7,
  });
  if (result.canceled) return;

  const uri = result.assets[0].uri;
  const uid = await AsyncStorage.getItem('user_id') || userId;
  const fileName = uid + '/' + Date.now() + '.jpg';

  // Convert to blob
  const response = await fetch(uri);
  const blob = await response.blob();

  // Upload to Supabase Storage
  const uploadRes = await fetch(
    SUPABASE_URL + '/storage/v1/object/orbit-images/' + fileName,
    {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + SUPABASE_ANON_KEY,
        'apikey': SUPABASE_ANON_KEY,
        'Content-Type': 'image/jpeg',
      },
      body: blob,
    }
  );

  if (!uploadRes.ok) { alert('upload failed'); return; }

  const publicUrl = SUPABASE_URL + '/storage/v1/object/public/orbit-images/' + fileName;

  // Show as image bubble in chat
  setMessages(prev => [...prev, {
    id: Date.now().toString(),
    text: '',
    imageUrl: publicUrl,
    isAI: false,
    confirmed: true,
    isImage: true,
  }]);
}
    const headers = await getAuthHeaders();
    await fetch(SUPABASE_URL + '/rest/v1/tasks?id=eq.' + id, {
      method: 'PATCH',
      headers: { ...headers, 'Content-Type': 'application/json', 'Prefer': 'return=minimal' },
      body: JSON.stringify({ done: !done })
    });
    setTasks(prev => prev.map(t => t.id === id ? { ...t, done: !t.done } : t));
  }

  // ── Send message ───────────────────────────────────────────────────────────
  async function sendMessage() {
    if (!input.trim()) return;
    // Block free users who hit the limit
    if (userPlan === 'free') {
      const count = await getDailyCount();
      if (count >= FREE_DAILY_LIMIT) {
        setLimitReached(true);
        return;
      }
    }
    const text = input;
    const uid = await AsyncStorage.getItem('user_id') || userId;
    const msgId = Date.now().toString();
    const userMessage = { id: msgId, text, isAI: false, confirmed: false };
    setInput('');
    setMessages(prev => [...prev, userMessage]);
    setLoading(true);
    try {
      const response = await fetch(SUPABASE_URL + '/functions/v1/extract-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + SUPABASE_ANON_KEY, 'apikey': SUPABASE_ANON_KEY },
        body: JSON.stringify({ content: text, user_id: uid }),
      });
      const data = await response.json();
      const total = (data.tasks?.length || 0) + (data.events?.length || 0) + (data.ideas?.length || 0) + (data.reminders?.length || 0);
      // Update both messages in one setState call to avoid batching issues
      const confirmedUserMsg = { ...userMessage, confirmed: true };
      saveMessageToSupabase(confirmedUserMsg, uid);
      setMessages(prev => {
        const confirmed = prev.map(m => m.id === msgId ? { ...m, confirmed: true } : m);
        if (total > 0) {
          const aiMsg = { id: (Date.now() + 1).toString(), text: '◉ orbit captured ' + total + ' item' + (total > 1 ? 's' : ''), isAI: true, confirmed: true };
          saveMessageToSupabase(aiMsg, uid);
          return [...confirmed, aiMsg];
        }
        return confirmed;
      });
      // Increment count after successful send
      if (userPlan === 'free') {
        const newCount = await incrementDailyCount();
        if (newCount >= FREE_DAILY_LIMIT) setLimitReached(true);
      }
    } catch (err) {
      setMessages(prev => prev.map(m => m.id === msgId ? { ...m, confirmed: true } : m));
    } finally { setLoading(false); }
  }

  // ── Render ─────────────────────────────────────────────────────────────────
  const filtered = search ? messages.filter(m => m.text?.toLowerCase().includes(search.toLowerCase())) : messages;
  const step = ONBOARDING[onboardStep];

  if (screen === 'loading') {
    return (
      <View style={[s.container, { alignItems: 'center', justifyContent: 'center', gap: 20 }]}>
        <Text style={{ fontSize: 32, color: C.midnight }}>◉</Text>
        <TouchableOpacity onPress={async () => { await AsyncStorage.clear(); setScreen('onboarding'); setOnboardStep(0); }}>
          <Text style={{ color: C.textMuted, fontSize: 13 }}>reset (testing only)</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (screen === 'onboarding') {
    return (
      <View style={s.container}>
        <View style={s.onboardWrap}>
          <View style={s.progressRow}>
            {ONBOARDING.map((_, i) => (
              <View key={i} style={[s.progressDot, i <= onboardStep && s.progressDotActive]} />
            ))}
          </View>
          <View style={{ flex: 1, justifyContent: 'center', paddingHorizontal: 8 }}>
            <Text style={s.orbitLogo}>◉ orbit</Text>
            <Text style={s.onboardTitle}>{step.title}</Text>
            {step.subtitle && <Text style={s.onboardSubtitle}>{step.subtitle}</Text>}

            {step.type === 'input' && (
              <TextInput
                style={s.onboardInput}
                placeholder={step.placeholder}
                placeholderTextColor={C.textMuted}
                value={profile[step.key] || ''}
                onChangeText={v => setProfile(p => ({ ...p, [step.key]: v }))}
                autoFocus
              />
            )}

            {step.type === 'choice' && (
              <View style={s.choiceGrid}>
                {step.options.map(opt => (
                  <TouchableOpacity
                    key={opt}
                    style={[s.choiceBtn, profile[step.key] === opt && s.choiceBtnActive]}
                    onPress={() => setProfile(p => ({ ...p, [step.key]: opt }))}>
                    <Text style={[s.choiceBtnText, profile[step.key] === opt && s.choiceBtnTextActive]}>{opt}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}

            {step.type === 'account' && (
              <View style={{ gap: 12, marginTop: 8 }}>
                <TextInput
                  style={s.onboardInput}
                  placeholder="email"
                  placeholderTextColor={C.textMuted}
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
                <TextInput
                  style={s.onboardInput}
                  placeholder="password"
                  placeholderTextColor={C.textMuted}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry
                />
                {/* Toggle login/signup */}
                <TouchableOpacity onPress={() => { setIsLogin(!isLogin); setEmail(''); setPassword(''); }}>
                  <Text style={{ color: C.cerulean, fontSize: 14, textAlign: 'center', marginTop: 4 }}>
                    {isLogin ? 'no account yet? sign up instead' : 'already have an account? log in'}
                  </Text>
                </TouchableOpacity>
                {/* Forgot password — only visible on login, separate line */}
                {isLogin && (
                  <TouchableOpacity
                    onPress={async () => {
                      if (!email) { alert('enter your email above first'); return; }
                      const { error } = await supabase.auth.resetPasswordForEmail(email);
                      if (error) alert('error: ' + error.message);
                      else alert('password reset email sent to ' + email);
                    }}>
                    <Text style={{ color: C.textMuted, fontSize: 13, textAlign: 'center', marginTop: 2 }}>
                      forgot password?
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            )}

          </View>

          <TouchableOpacity
            style={[s.ctaBtn, { opacity: (step.type === 'choice' && !profile[step.key]) ? 0.4 : 1 }]}
            onPress={() => {
              if (step.type === 'account') {
                if (!email || !password) { alert('please enter email and password'); return; }
                finishOnboarding();
                return;
              }
              if (onboardStep < ONBOARDING.length - 1) setOnboardStep(onboardStep + 1);
              else finishOnboarding();
            }}>
            <Text style={s.ctaBtnText}>
              {loading ? 'please wait…' : step.type === 'account' ? (isLogin ? 'log in' : 'create account') : step.cta}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  // ── Verify email screen ────────────────────────────────────────────────────
  if (screen === 'verify-email') {
    return (
      <View style={s.container}>
        <View style={s.onboardWrap}>
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 8 }}>
            <Text style={{ fontSize: 48, marginBottom: 24 }}>📬</Text>
            <Text style={s.onboardTitle}>check your email</Text>
            <Text style={s.onboardSubtitle}>
              we sent a confirmation link to{'\n'}
              <Text style={{ color: C.midnight, fontWeight: '500' }}>{profileEmail}</Text>
              {'\n\n'}tap the link in the email to verify your account, then come back here.
            </Text>
            <TouchableOpacity
              style={{ marginTop: 12 }}
              onPress={async () => {
                if (!profileEmail) return;
                const { error } = await supabase.auth.resend({ type: 'signup', email: profileEmail });
                if (error) alert('error resending: ' + error.message);
                else alert('email resent to ' + profileEmail);
              }}>
              <Text style={{ color: C.cerulean, fontSize: 14 }}>didn't get it? resend email</Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity
            style={s.ctaBtn}
            onPress={() => { setScreen('onboarding'); setOnboardStep(0); }}>
            <Text style={s.ctaBtnText}>use a different email</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  // ── Tutorial screen ────────────────────────────────────────────────────────
  if (screen === 'tutorial') {
    const step = TUTORIAL[tutorialStep];
    const isLast = tutorialStep === TUTORIAL.length - 1;
    return (
      <View style={s.container}>
        <View style={s.onboardWrap}>
          <View style={s.progressRow}>
            {TUTORIAL.map((_, i) => (
              <View key={i} style={[s.progressDot, i <= tutorialStep && s.progressDotActive]} />
            ))}
          </View>
          <View style={{ flex: 1, justifyContent: 'center', paddingHorizontal: 8 }}>
            <Text style={{ fontSize: 48, marginBottom: 24 }}>{step.emoji}</Text>
            <Text style={s.onboardTitle}>{step.title}</Text>
            <Text style={s.onboardSubtitle}>{step.subtitle}</Text>
            {step.examples.length > 0 && (
              <View style={{ gap: 10, marginTop: 8 }}>
                {step.examples.map((ex, i) => (
                  <View key={i} style={{ backgroundColor: C.white, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10, borderWidth: 0.5, borderColor: C.platinum }}>
                    <Text style={{ color: C.midnight, fontSize: 14, fontStyle: 'italic' }}>{ex}</Text>
                  </View>
                ))}
              </View>
            )}
          </View>
          <TouchableOpacity
            style={s.ctaBtn}
            onPress={() => {
              if (isLast) {
                setScreen('app');
              } else {
                setTutorialStep(tutorialStep + 1);
              }
            }}>
            <Text style={s.ctaBtnText}>{isLast ? 'start using orbit' : 'next'}</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  // ── Organised data ─────────────────────────────────────────────────────────
  const orgSections = [
    { type: 'section', title: 'tasks', id: 's1' },
    ...tasks.map(t => ({ ...t, type: 'task' })),
    ...(tasks.length === 0 ? [{ type: 'empty', text: 'no tasks yet', id: 'e1' }] : []),
    { type: 'section', title: 'events', id: 's2' },
    ...events.map(e => ({ ...e, type: 'event' })),
    ...(events.length === 0 ? [{ type: 'empty', text: 'no events yet', id: 'e2' }] : []),
    { type: 'section', title: 'ideas', id: 's3' },
    ...ideas.map(i => ({ ...i, type: 'idea' })),
    ...(ideas.length === 0 ? [{ type: 'empty', text: 'no ideas yet', id: 'e3' }] : []),
    { type: 'section', title: 'reminders', id: 's4' },
    ...reminders.map(r => ({ ...r, type: 'reminder' })),
    ...(reminders.length === 0 ? [{ type: 'empty', text: 'no reminders yet', id: 'e4' }] : []),
  ];

  return (
    <View style={s.container}>
      <ProModal visible={showPaywall} onClose={() => setShowPaywall(false)} onActivate={activatePro} />

      {/* Profile modal */}
      <Modal visible={showProfile} animationType="slide" transparent>
        <View style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.45)' }}>
          <View style={{ backgroundColor: C.white, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 28, paddingBottom: 52 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
              <Text style={{ fontSize: 22, color: C.midnight, fontWeight: '600' }}>◉ profile</Text>
              <TouchableOpacity onPress={() => setShowProfile(false)}>
                <Text style={{ color: C.textMuted, fontSize: 22 }}>×</Text>
              </TouchableOpacity>
            </View>
            <View style={{ gap: 14 }}>
              <View style={{ backgroundColor: C.bg, borderRadius: 12, padding: 14 }}>
                <Text style={{ color: C.textMuted, fontSize: 11, fontWeight: '600', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4 }}>name</Text>
                <Text style={{ color: C.midnight, fontSize: 16 }}>{profile.name || 'you'}</Text>
              </View>
              <View style={{ backgroundColor: C.bg, borderRadius: 12, padding: 14 }}>
                <Text style={{ color: C.textMuted, fontSize: 11, fontWeight: '600', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4 }}>email</Text>
                <Text style={{ color: C.midnight, fontSize: 16 }}>{profileEmail || '—'}</Text>
              </View>
              <View style={{ backgroundColor: C.bg, borderRadius: 12, padding: 14 }}>
                <Text style={{ color: C.textMuted, fontSize: 11, fontWeight: '600', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4 }}>messages today</Text>
                <Text style={{ color: C.midnight, fontSize: 16 }}>{dailyCount} / {FREE_DAILY_LIMIT} free</Text>
              </View>
            </View>
            <TouchableOpacity
              style={{ backgroundColor: C.platinum, borderRadius: 14, paddingVertical: 14, alignItems: 'center', marginTop: 24 }}
              onPress={handleLogout}>
              <Text style={{ color: C.midnight, fontSize: 15, fontWeight: '500' }}>log out</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {tab === 'chat' && (
        <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding" keyboardVerticalOffset={30}>
          <View style={s.header}>
            <TouchableOpacity onPress={async () => { const cnt = await getDailyCount(); setDailyCount(cnt); setShowProfile(true); }}>
              <Text style={s.headerText}>◉ orbit</Text>
            </TouchableOpacity>
            <View style={{ flexDirection: 'row', gap: 16, alignItems: 'center' }}>
              <TouchableOpacity onPress={async () => { await AsyncStorage.clear(); setScreen('onboarding'); setOnboardStep(0); }}>
                <Text style={{ color: C.textMuted, fontSize: 11 }}>reset</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => { setShowSearch(!showSearch); setSearch(''); }}>
                <Text style={{ color: C.cerulean, fontSize: 22 }}>⌕</Text>
              </TouchableOpacity>
            </View>
          </View>
          {showSearch && (
            <TextInput
              style={s.searchBox}
              value={search}
              onChangeText={setSearch}
              placeholder="search your thoughts…"
              placeholderTextColor={C.textMuted}
              autoFocus
              returnKeyType="done"
              onSubmitEditing={() => setShowSearch(false)}
            />
          )}
          <FlatList
            ref={flatListRef}
            data={filtered}
            keyExtractor={(item, index) => item?.id ?? index.toString()}
            contentContainerStyle={s.messageList}
            onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
            renderItem={({ item }) => <MessageBubble item={item} />}
          />
          {loading && <ActivityIndicator color={C.cerulean} style={{ marginBottom: 8 }} />}

          {/* Paywall banner replaces input when limit hit */}
          {limitReached ? (
            <View style={s.paywallBar}>
              <Text style={s.paywallTitle}>you've used all 30 free messages today</Text>
              <Text style={s.paywallSub}>come back tomorrow — resets at midnight 🌙</Text>
            </View>
          ) : (
            <View>
              {dailyCount >= 20 && (
                <Text style={{ textAlign: 'center', color: C.textMuted, fontSize: 12, paddingTop: 6, backgroundColor: C.white }}>
                  {FREE_DAILY_LIMIT - dailyCount} messages left today
                </Text>
              )}
            <View style={s.inputBar}>
            <TouchableOpacity onPress={pickAndUploadImage} style={{ paddingHorizontal: 4, paddingBottom: 6 }}>
  <Text style={{ fontSize: 22, color: C.cerulean }}>⊕</Text>
</TouchableOpacity>
              <TextInput
                style={s.input}
                value={input}
                onChangeText={setInput}
                placeholder="what's on your mind…"
                placeholderTextColor={C.textMuted}
                returnKeyType="send"
                onSubmitEditing={sendMessage}
                blurOnSubmit={true}
              />
              <TouchableOpacity style={s.sendBtn} onPress={sendMessage} disabled={loading}>
                <Text style={s.sendText}>↑</Text>
              </TouchableOpacity>
            </View>
            </View>
          )}
        </KeyboardAvoidingView>
      )}
    
      {tab === 'memories' && (
        <View style={{ flex: 1 }}>
          <View style={s.header}>
            <TouchableOpacity onPress={async () => { const cnt = await getDailyCount(); setDailyCount(cnt); setShowProfile(true); }}>
              <Text style={s.headerText}>◉ orbit</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={loadImages}>
              <Text style={{ color: C.cerulean, fontSize: 13 }}>refresh</Text>
            </TouchableOpacity>
          </View>
          {imagesLoading ? (
            <ActivityIndicator color={C.cerulean} style={{ marginTop: 40 }} />
          ) : images.length === 0 ? (
            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ fontSize: 32, marginBottom: 16 }}>📸</Text>
              <Text style={{ color: C.midnight, fontSize: 16, fontWeight: '500' }}>no memories yet</Text>
              <Text style={{ color: C.textMuted, fontSize: 14, marginTop: 8 }}>tap ⊕ in chat to add a photo</Text>
            </View>
          ) : (
            <FlatList
              data={images}
              keyExtractor={(item, i) => i.toString()}
              numColumns={3}
              contentContainerStyle={{ padding: 12, gap: 4 }}
              columnWrapperStyle={{ gap: 4 }}
              renderItem={({ item }) => (
                <Image
                  source={{ uri: item }}
                  style={{ width: (SIZE - 32) / 3, height: (SIZE - 32) / 3, borderRadius: 8 }}
                  resizeMode="cover"
                />
              )}
            />
          )}
        </View>
      )}
      {tab === 'organised' && (
        <View style={{ flex: 1 }}>
          <View style={s.header}>
            <Text style={s.headerText}>organised</Text>
            <TouchableOpacity onPress={loadOrganised}>
              <Text style={{ color: C.cerulean, fontSize: 13 }}>refresh</Text>
            </TouchableOpacity>
          </View>
          {orgLoading ? <ActivityIndicator color={C.cerulean} style={{ marginTop: 40 }} /> : (
            <FlatList
              data={orgSections}
              keyExtractor={(item, index) => item?.id ?? index.toString()}
              contentContainerStyle={{ padding: 16, gap: 8 }}
              renderItem={({ item }) => {
                if (item.type === 'section') return <Text style={s.sectionLabel}>{item.title}</Text>;
if (item.type === 'gallery') return (
  <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 8 }}>
    {item.urls.map((url, i) => (
      <Image key={i} source={{ uri: url }} style={{ width: 100, height: 100, borderRadius: 10 }} resizeMode="cover" />
    ))}
  </View>
);
                if (item.type === 'empty') return <Text style={s.emptyText}>{item.text}</Text>;
                if (item.type === 'task') return (
                  <TouchableOpacity style={s.card} onPress={() => toggleTask(item.id, item.done)}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                      <View style={{ width: 20, height: 20, borderRadius: 10, borderWidth: 1.5, borderColor: item.done ? C.midnight : C.bluegrey, backgroundColor: item.done ? C.midnight : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
                        {item.done && <Text style={{ color: '#fff', fontSize: 11 }}>✓</Text>}
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={[s.cardTitle, item.done && { color: C.textMuted, textDecorationLine: 'line-through' }]}>{item.title}</Text>
                        {item.due_date && <Text style={s.cardMeta}>due {item.due_date}</Text>}
                      </View>
                    </View>
                  </TouchableOpacity>
                );
                if (item.type === 'event') return (
                  <View style={s.card}>
                    <Text style={[s.cardMeta, { marginBottom: 4 }]}>event</Text>
                    <Text style={s.cardTitle}>{item.title}</Text>
                    {item.event_date_raw && <Text style={s.cardMeta}>{item.event_date_raw}</Text>}
                  </View>
                );
                if (item.type === 'idea') return (
                  <View style={[s.card, { borderLeftWidth: 2, borderLeftColor: C.baby }]}>
                    <Text style={[s.cardMeta, { marginBottom: 4 }]}>idea</Text>
                    <Text style={s.cardTitle}>{item.title}</Text>
                  </View>
                );
                if (item.type === 'reminder') return (
                  <View style={[s.card, { borderLeftWidth: 2, borderLeftColor: C.cerulean }]}>
                    <Text style={[s.cardMeta, { marginBottom: 4 }]}>reminder</Text>
                    <Text style={s.cardTitle}>{item.title}</Text>
                    {item.remind_at_raw && <Text style={s.cardMeta}>{item.remind_at_raw}</Text>}
                  </View>
                );
              }}
            />
          )}
        </View>
      )}

      <View style={s.tabBar}>
        <TouchableOpacity style={s.tab} onPress={() => setTab('chat')}>
          <Text style={[s.tabIcon, tab === 'chat' && s.tabActive]}>◉</Text>
          <Text style={[s.tabLabel, tab === 'chat' && s.tabActive]}>chat</Text>
        </TouchableOpacity>
        <TouchableOpacity style={s.tab} onPress={() => setTab('organised')}>
          <Text style={[s.tabIcon, tab === 'organised' && s.tabActive]}>☰</Text>
          <Text style={[s.tabLabel, tab === 'organised' && s.tabActive]}>organised</Text>
        </TouchableOpacity>
        <TouchableOpacity style={s.tab} onPress={() => setTab('memories')}>
          <Text style={[s.tabIcon, tab === 'memories' && s.tabActive]}>⊞</Text>
          <Text style={[s.tabLabel, tab === 'memories' && s.tabActive]}>memories</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { paddingTop: 60, paddingBottom: 16, paddingHorizontal: 20, borderBottomWidth: 0.5, borderBottomColor: C.platinum, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: C.white },
  headerText: { color: C.midnight, fontSize: 20, fontWeight: '500' },
  searchBox: { backgroundColor: C.white, color: C.midnight, margin: 12, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 10, fontSize: 15, borderWidth: 0.5, borderColor: C.bluegrey },
  messageList: { padding: 16, gap: 8 },
  bubble: { maxWidth: '80%', padding: 12, borderRadius: 18 },
  meBubble: { alignSelf: 'flex-end', backgroundColor: C.midnight, borderBottomRightRadius: 4 },
  aiBubble: { alignSelf: 'flex-start', backgroundColor: C.white, borderBottomLeftRadius: 4, borderWidth: 0.5, borderColor: C.platinum },
  bubbleText: { fontSize: 15, lineHeight: 21 },
  meText: { color: '#fff' },
  aiText: { color: C.midnight },
  inputBar: { flexDirection: 'row', padding: 12, paddingBottom: 40, gap: 7, borderTopWidth: 0.5, borderTopColor: C.platinum, alignItems: 'flex-end', backgroundColor: C.white },
  input: { flex: 1, backgroundColor: C.bg, color: C.midnight, borderRadius: 20, paddingHorizontal: 16, paddingVertical: 10, fontSize: 15, maxHeight: 100, borderWidth: 0.5, borderColor: C.bluegrey },
  sendBtn: { width: 38, height: 38, backgroundColor: C.midnight, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  sendText: { color: '#fff', fontSize: 18, fontWeight: '600' },
  paywallBar: { backgroundColor: C.midnight, padding: 16, paddingBottom: 40, alignItems: 'center', borderTopWidth: 0.5, borderTopColor: C.platinum },
  paywallTitle: { color: '#fff', fontSize: 14, fontWeight: '600' },
  paywallSub: { color: C.baby, fontSize: 13, marginTop: 5 },
  tabBar: { flexDirection: 'row', borderTopWidth: 0.5, borderTopColor: C.platinum, backgroundColor: C.white, paddingBottom: 28 },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 10, gap: 2 },
  tabIcon: { color: C.bluegrey, fontSize: 18 },
  tabLabel: { color: C.bluegrey, fontSize: 11 },
  tabActive: { color: C.midnight },
  card: { backgroundColor: C.white, borderRadius: 12, padding: 14, borderWidth: 0.5, borderColor: C.platinum },
  cardTitle: { color: C.midnight, fontSize: 15 },
  cardMeta: { color: C.textMuted, fontSize: 12, marginTop: 4 },
  sectionLabel: { color: C.textMuted, fontSize: 11, fontWeight: '600', letterSpacing: 1, textTransform: 'uppercase', marginTop: 8 },
  emptyText: { color: C.bluegrey, fontSize: 13, paddingLeft: 4 },
  onboardWrap: { flex: 1, padding: 28, paddingTop: 60 },
  progressRow: { flexDirection: 'row', gap: 6, marginBottom: 40 },
  progressDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: C.platinum },
  progressDotActive: { backgroundColor: C.midnight },
  orbitLogo: { fontSize: 16, color: C.cerulean, marginBottom: 24, fontWeight: '500' },
  onboardTitle: { fontSize: 28, color: C.midnight, fontWeight: '500', lineHeight: 36, marginBottom: 12 },
  onboardSubtitle: { fontSize: 16, color: C.textMuted, lineHeight: 24, marginBottom: 32 },
  onboardInput: { backgroundColor: C.white, borderWidth: 0.5, borderColor: C.bluegrey, borderRadius: 14, paddingHorizontal: 18, paddingVertical: 14, fontSize: 16, color: C.midnight, marginTop: 8 },
  choiceGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 8 },
  choiceBtn: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20, borderWidth: 0.5, borderColor: C.bluegrey, backgroundColor: C.white },
  choiceBtnActive: { backgroundColor: C.midnight, borderColor: C.midnight },
  choiceBtnText: { color: C.midnight, fontSize: 14 },
  choiceBtnTextActive: { color: '#fff' },
  ctaBtn: { backgroundColor: C.midnight, borderRadius: 16, paddingVertical: 16, alignItems: 'center', marginBottom: 40 },
  ctaBtnText: { color: '#fff', fontSize: 16, fontWeight: '500' },
  planCard: { backgroundColor: C.white, borderRadius: 16, padding: 18, borderWidth: 0.5, borderColor: C.platinum },
  planCardActive: { borderColor: C.midnight, borderWidth: 1.5 },
  planTitle: { fontSize: 18, color: C.midnight, fontWeight: '500', marginBottom: 6 },
  planDesc: { fontSize: 13, color: C.textMuted, lineHeight: 20 },
  planBadge: { backgroundColor: C.baby, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 3, alignSelf: 'flex-start', marginBottom: 8 },
  planBadgeText: { fontSize: 11, color: C.midnight, fontWeight: '500' },
});